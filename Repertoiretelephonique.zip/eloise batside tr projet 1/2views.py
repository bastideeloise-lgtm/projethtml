from flask import Flask, render_template, request

app = Flask(__name__)



def ecriture(nom, num): #la fonction ecriture possède 2 variables: nom et num
    with open('répertoire téléphonique.txt', 'a') as f :
        f.write(nom)
        f.write('\n') 
    with open('répertoire téléphonique.txt', 'a') as f :
        f.write(num)
        f.write('\n') #écris dans le repertoire telephonique le nom et dans la ligne suivante le numéro



def lecture(nomst):
    noms=[]
    b=0
    with open('répertoire téléphonique.txt','r') as f :
        for ligne in f:
            ligne=ligne.replace("\n","")
            noms.append(ligne) #cela permet de lire le fichier et de ranger les noms et les numéros entrés par l'utilisateur dans une liste
    for i in noms:
        if nomst==str(i):
            num=noms[b+1]
            return num
        b=b+1#si le nom est dans le fichier le programme renvoi ce qui est marqué dans la ligne suivante donc le numéro
    num=""
    return num


@app.route('/')
def index():
    return render_template("index.html")# on affiche vers la page HTML 


@app.route('/recherche')
def recherche():
    return render_template("recherche.html")# on affiche vers la page HTML 


@app.route('/ajout')
def ajout():
    return render_template("ajout.html")# on affiche vers la page HTML 


@app.route('/resultr',methods = ['GET'])
def resultr():
    result=request.args # on récupère les infos (numéro à rechercher) de la page HTML
    nom=result['nom']
    num=lecture(nom)
    if num=="":
        num="inconnu"
    return render_template("resultr.html", nom=nom, num=num) # on affiche vers la page HTML le résultat de la recherche

@app.route('/resulta',methods = ['GET'])
def resulta(): # page de résultat de l'écriture du nom et numéro dans annuaire.txt
    result=request.args # on récupère les infos (nom et numéro à sauvegarder) de la page HTML
    nom=result['nom']
    num=result['num']
    ecriture(nom, num)
    return render_template("resulta.html", nom=nom, num=num) # on affiche vers la page HTML le résultat

app.run(debug=True)