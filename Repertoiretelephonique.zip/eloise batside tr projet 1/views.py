from flask import Flask, render_template, request
import sqlite3

app = Flask(__name__)


conn = sqlite3.connect('baseDonnees.db') #création du fiché sql
cur = conn.cursor()

cur.execute("CREATE TABLE IF NOT EXISTS Répertoire(nom TEXT, num INT)") #création de la table

conn.commit() #validation des changements dans la base de données

cur.close() #fermeture du curseur
conn.close() #fermeture de la connexion à la base de données




def ecriture(nom, num): #la fonction ecriture possède 2 variables: nom et num
    conn = sqlite3.connect('baseDonnees.db') # on va sur sql
    cur = conn.cursor() #création d'un objet curseur
    data = (nom,num) #les 2 variables qu'on n'a besoin pour enregistrer le num et le nom
    cur.execute("CREATE TABLE IF NOT EXISTS Répertoire(nom TEXT, num INT)") #on s'assure que la table exite
    cur.execute("INSERT INTO Répertoire(nom, num) VALUES(?, ?)", data) #on insert les données dans la table
    conn.commit() #validation des changements

    cur.close()
    conn.close()

def lecture(nom): #fonction pour lire les base de données afin de pouvoir les recherchers dans le site
    conn = sqlite3.connect('baseDonnees.db') 
    cur = conn.cursor() 
    cur.execute("SELECT num FROM Répertoire WHERE nom = ?", (nom,)) #requête pour le numéro associé au nom
    result = cur.fetchone() # on récupert le résultat
    cur.close() 
    conn.close()
    if result: #vérification si un résultat a été trouvé
        return result[0] # si on n'a le numéro on le marque
    else:
        
        return "Inconnu" #sinon on marque inconnu


@app.route('/')
def index():
    return render_template("index.html")# on affiche vers la page HTML 


@app.route('/recherche')
def recherche():
    return render_template("recherche.html")# on affiche vers la page HTML 


@app.route('/ajout')
def ajout():
    return render_template("ajout.html")# on affiche vers la page HTML 


@app.route('/resultr',methods = ['GET'])
def resultr():
    result=request.args # on récupère les infos (numéro à rechercher) de la page HTML
    nom=result['nom'] #extraire le nom des paramètres de requête
    num=lecture(nom)  #on va dans lecture pour le nom et le num
    
    return render_template("resultr.html", nom=nom, num=num) # on affiche vers la page HTML le résultat de la recherche

@app.route('/resulta',methods = ['GET'])
def resulta(): # page de résultat de l'écriture du nom et numéro dans annuaire.txt
    result=request.args # on récupère les infos (nom et numéro à sauvegarder) de la page HTML
    nom=result['nom']
    num=result['num']
    ecriture(nom, num)
    return render_template("resulta.html", nom=nom, num=num) # on affiche vers la page HTML le résultat

app.run(debug=True)